import React from 'react';
import { GraduationCap, MapPin, Phone, Mail, Globe } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-blue-600 p-2 rounded-lg">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Kyrgyz Medical University</h3>
                <p className="text-gray-400">Excellence in Medical Education</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Shaping the future of healthcare through world-class medical education. 
              Join us in our mission to create skilled, compassionate healthcare professionals.
            </p>
            <div className="flex space-x-4">
              <button className="bg-blue-600 hover:bg-blue-700 p-3 rounded-lg transition-colors duration-200">
                <Globe className="h-5 w-5" />
              </button>
              <button className="bg-green-600 hover:bg-green-700 p-3 rounded-lg transition-colors duration-200">
                <Mail className="h-5 w-5" />
              </button>
              <button className="bg-purple-600 hover:bg-purple-700 p-3 rounded-lg transition-colors duration-200">
                <Phone className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors duration-200">About University</a></li>
              <li><a href="#facilities" className="text-gray-300 hover:text-white transition-colors duration-200">Facilities</a></li>
              <li><a href="#rankings" className="text-gray-300 hover:text-white transition-colors duration-200">Rankings</a></li>
              <li><a href="#apply" className="text-gray-300 hover:text-white transition-colors duration-200">Apply Now</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Student Portal</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-gray-300">Akhunbaev Street 92</p>
                  <p className="text-gray-300">Bishkek 720020, Kyrgyzstan</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-400" />
                <p className="text-gray-300">+996 312 123 456</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <p className="text-gray-300">info@kmu.edu.kg</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">
              © 2025 Kyrgyz Medical University. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Student Handbook</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;